function validarIdade() {
  const anoNascimento = prompt("Qual seu ano de nascimento?");
  const idade = 2022 - anoNascimento;
  if(idade >= 18) {
    alert("Você está autorizado(a) a jogar!");
  } else {
    alert("Ops! Você ainda não tem idade para jogar!");
  }
}